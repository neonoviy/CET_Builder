<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'Part of Content Editor Tools. Supports CET_assetsTV for file management.
Adds CKEditor as Rich Text Editor and CodeMirror for code. You can add RTE to description and introtext. All settings in plugin\'s preferences tab.
Author Denis Dyranov (Dyranov.ru)
Version: 0.5',
    'changelog' => 'Changelog for Content Editor Tools Builder

0.5-beta1 (12.02.2016)
===========
- Initial Version',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '318415d2b5793c83d860f6d1df1365c4',
      'native_key' => 'cetbuilder',
      'filename' => 'modNamespace/240e88a943b777424934d14998655cb0.vehicle',
      'namespace' => 'cetbuilder',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'd770a08a46694270ed729e4a7b5ee54b',
      'native_key' => 21,
      'filename' => 'modPlugin/581727185a6f53991a315034dde73d58.vehicle',
      'namespace' => 'cetbuilder',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '082a1502f1f5178f3e5efb77f77f3999',
      'native_key' => 1,
      'filename' => 'modCategory/a7a762d5c6e80643d5dcb033cfe8bd10.vehicle',
      'namespace' => 'cetbuilder',
    ),
  ),
);